var i = 100;
console.log(i);

function hello() {
	console.log("Hello to All");
}

hello();