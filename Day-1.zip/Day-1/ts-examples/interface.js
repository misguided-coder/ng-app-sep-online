var Bus = /** @class */ (function () {
    //speed:number;
    //speed:number = 150;
    //name:string = "Merc 1000D";
    //name:string;
    function Bus(name, speed) {
        if (name === void 0) { name = 'BMW 2200CC'; }
        if (speed === void 0) { speed = 400; }
        this.name = name;
        this.speed = speed;
        console.log("Inside Bus constructor()!!!!");
        //this.speed = 200;
        //this.name = "Merc 2000D";
        //this.name = name;
        //this.speed = speed;
    }
    Bus.prototype.info = function () {
        console.log("Name  : " + this.name);
        console.log("Speed  : " + this.speed);
    };
    Bus.prototype.start = function () {
        console.log("Bus engine started");
    };
    Bus.prototype.speedUp = function () {
        console.log("Bus is running at the speed of " + this.speed + " KM per hour");
        console.log("Bus is running at the speed of $this.speed KM per hour");
        console.log('Bus is running at the speed of $this.speed KM per hour');
        console.log("Bus is running at the speed of " + this.speed + " KM per hour");
        console.log("Bus is running at the speed of " + (this.speed + 100 / 2 * 10) + " KM per hour");
        console.log("Bus is running at the speed of " + 100 / 2 * 10 + " KM per hour");
    };
    Bus.prototype.stop = function () {
        console.log("Bus engine stopped");
    };
    Bus.prototype.repair = function () {
        console.log("Bus engine repaired");
    };
    return Bus;
}());
var bus = new Bus();
//var bus:Bus = new Bus("Volvo XXL",350);
//var bus:Bus = new Bus("Volvo XXL","Three Fifty");
bus.info();
bus.start();
bus.speedUp();
bus.stop();
bus.repair();
