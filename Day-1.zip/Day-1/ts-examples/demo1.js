var age = 20;
console.log(age);
var data = "Hello";
console.log(data);
