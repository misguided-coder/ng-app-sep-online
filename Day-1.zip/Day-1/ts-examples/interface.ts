interface Automobile {
	start();
	stop();
}

interface Acceleratable {
	speedUp();
}

interface Repairable {
	repair();
}

class Bus implements Automobile,Acceleratable,Repairable  {

	//speed:number;
	//speed:number = 150;
	//name:string = "Merc 1000D";
	//name:string;

	constructor(public name:string='BMW 2200CC',private speed:number=400) {
		console.log("Inside Bus constructor()!!!!");
		//this.speed = 200;
		//this.name = "Merc 2000D";
		//this.name = name;
		//this.speed = speed;
	}

	info() {
		console.log(`Name  : ${this.name}`);
		console.log(`Speed  : ${this.speed}`);
	}
	
	start() {
		console.log("Bus engine started");
	}

	speedUp() {
		console.log("Bus is running at the speed of "+this.speed+" KM per hour");
		console.log("Bus is running at the speed of $this.speed KM per hour");
		console.log('Bus is running at the speed of $this.speed KM per hour');
		console.log(`Bus is running at the speed of ${this.speed} KM per hour`);
		console.log(`Bus is running at the speed of ${this.speed + 100 /2 * 10} KM per hour`);
		console.log(`Bus is running at the speed of ${100 /2 * 10} KM per hour`);
	}

	stop() {
		console.log("Bus engine stopped");
	}

	repair() {
		console.log("Bus engine repaired");
	}

}

var bus:Bus = new Bus();
//var bus:Bus = new Bus("Volvo XXL",350);
//var bus:Bus = new Bus("Volvo XXL","Three Fifty");

bus.info()
bus.start()
bus.speedUp()
bus.stop()
bus.repair()




