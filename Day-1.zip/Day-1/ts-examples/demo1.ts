var age:number = 20
console.log(age);

var data:any = "Hello"
console.log(data);


