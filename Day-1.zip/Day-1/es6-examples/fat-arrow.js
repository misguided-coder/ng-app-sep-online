//Developer A
function calculate(x,y,fn) {
	console.log("Loading initial data from DB....");
	console.log("Preparing  initial data....");
	console.log("Doing initial calculations....");
	var rs = fn(x,y);
	console.log("Result : "+rs);
	console.log("Calculation done....");
}


//Developer B,C,D
calculate(50,5,(a,b) => a+b);
calculate(50,5,(a,b) => a-b);
calculate(50,5,(a,b) => a*b);
calculate(50,5,(a,b) => a/b);
calculate(50,5,(a,b) => a%b);
calculate(50,5,(a,b) => a+a+b);
calculate(50,5,(a,b) => a+b+b);

//fat arrow functions
var bye = () => {
	console.log("Bye All");
};

bye();

//anonymous functions
var hi = function () {
	console.log("Hi All");
}

hi();

//named functions
function greet() {
	console.log("Hello All");
}

greet();



