var array = [20,12,8,6];
var emp = {id:100,name:'Rohan',age:20};

var valueA = array[0]
var valueB = array[1]
var valueC = array[2]
var valueD = array[3]

var id = emp.id
var name = emp.name
var age = emp.age

console.log(valueA)
console.log(valueB)
console.log(valueC)
console.log(valueD)

console.log("======================")

console.log(id)
console.log(name)
console.log(age)

console.log("======================")

var [A,B,C,D] = array
console.log(A)
console.log(B)
console.log(C)
console.log(D)

console.log("======================")

var {id,name,age} = emp
console.log(id)
console.log(name)
console.log(age)








