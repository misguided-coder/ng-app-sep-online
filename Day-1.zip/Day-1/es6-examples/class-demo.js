class Car {
	
	constructor() {
		console.log("Inside Car constructor()!!");
		this.name = "Audi Q3";
		this.speed = 200;
	}

	speedUp() {
		this.speed = this.speed + 10;
	}

	speedDown() {
		this.speed = this.speed - 10;
	}
}

var car1 = new Car();
console.log(car1.name);
car1.name = "Audi Q2";
console.log(car1.name);

car1.speedUp();
car1.speedUp();
car1.speedUp();
car1.speedDown();

console.log(car1.speed);





