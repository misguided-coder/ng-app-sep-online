function cal(a,b,c) {
	console.log("Result : "+(a+b+c));
}

/*function cal(a,b,c,d,e,f) {
	console.log("Result : "+(a+b+c+d+e+f));
}*/

cal(10,10,10)

var array = [20,12,8,6,12,45];
console.log(array);
console.log(array[1]);

//cal(array)
cal(array[0],array[1],array[2])
cal(...array)






