class Car {
	
	constructor() {
		console.log("Inside Car constructor()!!");
		this.name = "Audi Q3";
		this.speed = 200;
	}

	speedUp() {
		this.speed = this.speed + 10;
	}

	speedDown() {
		this.speed = this.speed - 10;
	}
}

class LuxuryCar extends Car {
	
	constructor() {
		super();
		console.log("Inside LuxuryCar constructor()!!");
		//this.doors = 2;
	}

	speedUp() {
		this.speed = this.speed + 50;
	}

	speedDown() {
		this.speed = this.speed - 50;
	}
}

var car1 = new LuxuryCar();
console.log(car1.name);
console.log(car1.speed);
console.log(car1.doors);

car1.speedUp();
car1.speedUp();
car1.speedUp();
car1.speedDown();

console.log(car1.speed);





