function doWork() {
	
	const marks = 670;
	//marks = 770; //Will not work

	console.log(marks);

	for(let counter = 1; counter <= 10;counter++) {
		console.log(counter);
	}
	
	//console.log(counter); //Will not work

	{
		let x = 10000;
		console.log(x);
	}
	//console.log(x);  //Will not work

       	if(true) {
		var i = 1000;
		let j = 1000;
		console.log(i);
		console.log(j);
	}
	console.log(i);
	//console.log(j); //Will not work
}

doWork();



